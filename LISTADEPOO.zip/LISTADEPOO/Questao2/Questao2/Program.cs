﻿using System;

class ContaBancaria
{
    public string NumeroConta { get; set; }
    public string Titular { get; set; }
    public double Saldo { get; private set; }

    public void Depositar(double valor)
    {
        if (valor > 0)
        {
            Saldo += valor;
            Console.WriteLine($"Depósito de R${valor:F2} realizado com sucesso.");
        }
        else
        {
            Console.WriteLine("Valor de depósito inválido.");
        }
    }

    public void Sacar(double valor)
    {
        if (valor > 0)
        {
            if (Saldo >= valor)
            {
                Saldo -= valor;
                Console.WriteLine($"Saque de R${valor:F2} realizado com sucesso.");
            }
            else
            {
                Console.WriteLine("Saldo insuficiente para realizar o saque.");
            }
        }
        else
        {
            Console.WriteLine("Valor de saque inválido.");
        }
    }

    public void ExibirSaldo()
    {
        Console.WriteLine($"Saldo atual da conta {NumeroConta}: R${Saldo:F2}");
    }

    public void ExibirDados()
    {
        Console.WriteLine($"Conta: {NumeroConta}");
        Console.WriteLine($"Titular: {Titular}");
        ExibirSaldo();
    }
}

class Program
{
    static void Main(string[] args)
    {
        ContaBancaria conta = new ContaBancaria();

        Console.Write("Digite o número da conta: ");
        conta.NumeroConta = Console.ReadLine();

        Console.Write("Digite o nome do titular: ");
        conta.Titular = Console.ReadLine();

        bool executar = true;

        while (executar)
        {
            Console.WriteLine("\nEscolha uma opção:");
            Console.WriteLine("1 - Depositar");
            Console.WriteLine("2 - Sacar");
            Console.WriteLine("3 - Exibir Saldo");
            Console.WriteLine("4 - Exibir Dados da Conta");
            Console.WriteLine("5 - Sair");

            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    Console.Write("Digite o valor do depósito: ");
                    double valorDeposito = double.Parse(Console.ReadLine());
                    conta.Depositar(valorDeposito);
                    break;

                case "2":
                    Console.Write("Digite o valor do saque: ");
                    double valorSaque = double.Parse(Console.ReadLine());
                    conta.Sacar(valorSaque);
                    break;

                case "3":
                    conta.ExibirSaldo();
                    break;

                case "4":
                    conta.ExibirDados();
                    break;

                case "5":
                    Console.WriteLine("Saindo... Até logo!");
                    executar = false;
                    break;

                default:
                    Console.WriteLine("Opção inválida! Tente novamente.");
                    break;
            }
        }
    }
}
