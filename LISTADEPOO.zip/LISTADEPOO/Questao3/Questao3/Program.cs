﻿using System;

class Produto
{
    public string Nome { get; set; }
    public double Preco { get; set; }
    public int Quantidade { get; private set; }

    public void AdicionarEstoque(int quantidade)
    {
        if (quantidade > 0)
        {
            Quantidade += quantidade;
            Console.WriteLine($"Adicionado {quantidade} unidades ao estoque.");
        }
        else
        {
            Console.WriteLine("Quantidade inválida. O valor deve ser positivo.");
        }
    }

    public void RemoverEstoque(int quantidade)
    {
        if (quantidade > 0)
        {
            if (Quantidade >= quantidade)
            {
                Quantidade -= quantidade;
                Console.WriteLine($"Removido {quantidade} unidades do estoque.");
            }
            else
            {
                Console.WriteLine("Quantidade insuficiente no estoque.");
            }
        }
        else
        {
            Console.WriteLine("Quantidade inválida. O valor deve ser positivo.");
        }
    }

    public void ExibirDetalhes()
    {
        Console.WriteLine("\nDetalhes do Produto:");
        Console.WriteLine($"Nome: {Nome}");
        Console.WriteLine($"Preço: R${Preco:F2}");
        Console.WriteLine($"Quantidade em estoque: {Quantidade}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        Produto produto = new Produto();

        Console.Write("Digite o nome do produto: ");
        produto.Nome = Console.ReadLine();

        Console.Write("Digite o preço do produto: ");
        produto.Preco = double.Parse(Console.ReadLine());

        Console.Write("Digite a quantidade inicial em estoque: ");
        produto.Quantidade = int.Parse(Console.ReadLine());

        bool executar = true;

        while (executar)
        {
            Console.WriteLine("\nEscolha uma opção:");
            Console.WriteLine("1 - Adicionar unidades ao estoque");
            Console.WriteLine("2 - Remover unidades do estoque");
            Console.WriteLine("3 - Exibir detalhes do produto");
            Console.WriteLine("4 - Sair");

            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1":
                    Console.Write("Digite a quantidade a ser adicionada ao estoque: ");
                    int quantidadeAdicionar = int.Parse(Console.ReadLine());
                    produto.AdicionarEstoque(quantidadeAdicionar);
                    break;

                case "2":
                    Console.Write("Digite a quantidade a ser removida do estoque: ");
                    int quantidadeRemover = int.Parse(Console.ReadLine());
                    produto.RemoverEstoque(quantidadeRemover);
                    break;

                case "3":
                    produto.ExibirDetalhes();
                    break;

                case "4":
                    Console.WriteLine("Saindo... Até logo!");
                    executar = false;
                    break;

                default:
                    Console.WriteLine("Opção inválida! Tente novamente.");
                    break;
            }
        }
    }
}
